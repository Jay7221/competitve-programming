#include<bits/stdc++.h>
using namespace std;
#define ll long long
void solve(){
}
int main()
{
	int T;
	cin >> T;
	for(int t = 1; t <= T; ++t)
	{
		solve();
	}
	return 0;
}
